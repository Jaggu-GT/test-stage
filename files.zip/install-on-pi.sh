#!/bin/bash
# deploy/install-on-pi.sh — install QwenFunc on Raspberry Pi 3B+
#
# Run as your normal user (sudo will be invoked as needed). Idempotent.
# Per specs/03-architecture.md §9.
#
# Preflight assumptions (deploy aborts if any fail):
#   - Debian Trixie
#   - harden-pi.sh has run (auditd, ufw, AppArmor active)
#   - Ollama installed and serving on 127.0.0.1:11434
#   - This repo cloned somewhere accessible to the deployer
#
# Usage:
#   ./deploy/install-on-pi.sh                # install
#   ./deploy/install-on-pi.sh --uninstall    # remove everything

set -euo pipefail
export LC_ALL=C PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
log()  { echo -e "\n\033[1;32m[+]\033[0m $*"; }
fail() { echo -e "\033[1;31m[✗]\033[0m $*" >&2; exit 1; }

# ─── Argument parsing ────────────────────────────────────────────────────────
UID_LAYOUT="$REPO_ROOT/deploy/uid-layout.conf"
DO_UNINSTALL=0
while [[ $# -gt 0 ]]; do
    case "$1" in
        --uid-layout) UID_LAYOUT="$2"; shift 2 ;;
        --uninstall)  DO_UNINSTALL=1; shift ;;
        --help|-h)
            cat <<USAGE
$(basename "$0") — install QwenFunc on a Pi.

Usage:
  $(basename "$0")                              install with default layout
  $(basename "$0") --uid-layout PATH            use custom UID/GID layout
  $(basename "$0") --uninstall                  remove everything

The default layout (deploy/uid-layout.conf) uses UIDs 900-902 and GID 903.
For other Pi platforms (Pi Zero 2W, Pi 5), copy that file, edit the values,
and pass --uid-layout to point at it. Stable UIDs matter for backup/restore.
USAGE
            exit 0 ;;
        *) fail "unknown argument: $1" ;;
    esac
done

# Source the UID layout (defines USERS_TO_CREATE, GROUPS_TO_CREATE).
[[ -f "$UID_LAYOUT" ]] || fail "uid-layout file not found: $UID_LAYOUT"
# shellcheck source=deploy/uid-layout.conf
source "$UID_LAYOUT"
[[ -n "${USERS_TO_CREATE:-}" ]] || fail "uid-layout missing USERS_TO_CREATE"
[[ -n "${GROUPS_TO_CREATE:-}" ]] || fail "uid-layout missing GROUPS_TO_CREATE"

# ─── Preflight ───────────────────────────────────────────────────────────────
[[ $EUID -eq 0 ]] && fail "Run as your user, not root."
sudo -v || fail "sudo required."
[[ -f /etc/debian_version ]] || fail "not a Debian system"
. /etc/os-release
[[ "$VERSION_CODENAME" == "trixie" ]] || fail "Debian Trixie required (got $VERSION_CODENAME)"

systemctl is-active --quiet auditd || fail "auditd not active (run harden-pi.sh first)"
systemctl is-active --quiet apparmor || fail "apparmor not active (run harden-pi.sh first)"
sudo ufw status | grep -q "Status: active" || fail "ufw not active (run harden-pi.sh first)"

# Ollama check (best-effort — only warn if missing).
if ! curl -fsS http://127.0.0.1:11434/api/version >/dev/null 2>&1; then
    echo "WARN: Ollama not reachable at 127.0.0.1:11434. Wrapper will fail at runtime."
fi

# ─── Uninstall path ──────────────────────────────────────────────────────────
if [[ "$DO_UNINSTALL" -eq 1 ]]; then
    log "Uninstalling QwenFunc…"
    sudo systemctl disable --now qwenfunc-canary.timer 2>/dev/null || true
    sudo systemctl disable --now qwenfunc-logrotate.timer 2>/dev/null || true
    sudo rm -f /etc/sudoers.d/qwenfunc /etc/audit/rules.d/qwenfunc.rules
    sudo rm -f /etc/apparmor.d/usr.local.bin.qwenfunc-cli
    sudo rm -f /etc/apparmor.d/usr.local.libexec.op-reader
    sudo apparmor_parser -R /etc/apparmor.d/usr.local.bin.qwenfunc-cli 2>/dev/null || true
    sudo apparmor_parser -R /etc/apparmor.d/usr.local.libexec.op-reader 2>/dev/null || true
    sudo augenrules --load
    sudo rm -rf /etc/qwenfunc /usr/local/lib/qwenfunc
    sudo rm -f /usr/local/bin/qwenfunc /usr/local/bin/qwenfunc-cli
    sudo rm -f /usr/local/libexec/op-reader
    sudo rm -f /usr/local/sbin/qwenfunc-logrotate.sh
    sudo chattr -a /var/log/qwenfunc/decisions.jsonl 2>/dev/null || true
    sudo rm -rf /var/log/qwenfunc /var/lib/qwenfunc
    # Remove users/groups in reverse order, per uid-layout.
    while IFS=':' read -r uid gid name; do
        sudo userdel "$name" 2>/dev/null || true
    done <<< "$USERS_TO_CREATE"
    while IFS=':' read -r gid name; do
        sudo groupdel "$name" 2>/dev/null || true
    done <<< "$GROUPS_TO_CREATE"
    log "Uninstall complete."
    exit 0
fi

# ─── 1. Users & groups (driven by uid-layout) ────────────────────────────────
log "Creating users and groups from $UID_LAYOUT…"

# Helper: create user with pinned UID/GID; refuse if user exists at wrong UID.
create_user_pinned() {
    local uid="$1" gid="$2" name="$3"
    if id "$name" >/dev/null 2>&1; then
        local existing_uid existing_gid
        existing_uid=$(id -u "$name")
        existing_gid=$(id -g "$name")
        if [[ "$existing_uid" != "$uid" || "$existing_gid" != "$gid" ]]; then
            fail "user $name exists with uid=$existing_uid gid=$existing_gid; layout requires uid=$uid gid=$gid. Refusing to silently rebuild — fix manually or uninstall first."
        fi
        return 0  # already exists at correct UID/GID
    fi
    # Group must exist at correct GID first.
    if ! getent group "$gid" >/dev/null; then
        sudo groupadd --system --gid "$gid" "$name"
    fi
    sudo useradd --system --uid "$uid" --gid "$gid" \
        --no-create-home --shell /usr/sbin/nologin "$name"
}

create_group_pinned() {
    local gid="$1" name="$2"
    if getent group "$name" >/dev/null; then
        local existing_gid
        existing_gid=$(getent group "$name" | cut -d: -f3)
        if [[ "$existing_gid" != "$gid" ]]; then
            fail "group $name exists with gid=$existing_gid; layout requires gid=$gid."
        fi
        return 0
    fi
    sudo groupadd --system --gid "$gid" "$name"
}

while IFS=':' read -r gid name; do
    create_group_pinned "$gid" "$name"
done <<< "$GROUPS_TO_CREATE"

while IFS=':' read -r uid gid name; do
    create_user_pinned "$uid" "$gid" "$name"
done <<< "$USERS_TO_CREATE"

# Add the deployer to qwenfunc-users so they can run the shim.
if ! id -nG "$USER" | grep -qw qwenfunc-users; then
    sudo usermod -a -G qwenfunc-users "$USER"
    echo "NOTE: added $USER to qwenfunc-users; log out + back in for it to take effect."
fi

# ─── 2. Directories ──────────────────────────────────────────────────────────
log "Creating directories…"
sudo install -d -m 0750 -o root      -g qwenfunc /etc/qwenfunc
sudo install -d -m 0700 -o qwenfunc  -g qwenfunc /var/lib/qwenfunc
sudo install -d -m 0750 -o qwenfunc  -g adm      /var/log/qwenfunc
sudo install -d -m 0755 -o root      -g root     /usr/local/lib/qwenfunc
sudo install -d -m 0755 -o root      -g root     /usr/local/libexec

# ─── 3. Code & binaries ──────────────────────────────────────────────────────
log "Installing code…"
# Wrapper package
sudo install -m 0644 -o root -g root "$REPO_ROOT/src/qwenfunc/__init__.py" /usr/local/lib/qwenfunc/
sudo install -m 0644 -o root -g root "$REPO_ROOT/src/qwenfunc/audit.py" /usr/local/lib/qwenfunc/
sudo install -m 0644 -o root -g root "$REPO_ROOT/src/qwenfunc/cli.py" /usr/local/lib/qwenfunc/
sudo install -m 0644 -o root -g root "$REPO_ROOT/src/qwenfunc/globs.py" /usr/local/lib/qwenfunc/
sudo install -m 0644 -o root -g root "$REPO_ROOT/src/qwenfunc/llm.py" /usr/local/lib/qwenfunc/
sudo install -m 0644 -o root -g root "$REPO_ROOT/src/qwenfunc/policy.py" /usr/local/lib/qwenfunc/
sudo install -m 0644 -o root -g root "$REPO_ROOT/src/qwenfunc/schema.py" /usr/local/lib/qwenfunc/
sudo install -m 0644 -o root -g root "$REPO_ROOT/src/qwenfunc/lint_policy.py" /usr/local/lib/qwenfunc/

# Wrapper entry point — wrapping shim that adds the package to sys.path
sudo tee /usr/local/bin/qwenfunc-cli >/dev/null <<'EOF'
#!/usr/bin/env python3
import sys
sys.path.insert(0, "/usr/local/lib")
from qwenfunc.cli import run_cli
sys.exit(run_cli())
EOF
sudo chmod 0755 /usr/local/bin/qwenfunc-cli
sudo chown root:root /usr/local/bin/qwenfunc-cli

# Operator binary
sudo install -m 0755 -o root -g root "$REPO_ROOT/src/op_reader/op_reader.py" /usr/local/libexec/op-reader

# Human entry shim
sudo install -m 0750 -o root -g qwenfunc-users "$REPO_ROOT/deploy/qwenfunc" /usr/local/bin/qwenfunc

# Logrotate script
sudo install -m 0750 -o root -g root "$REPO_ROOT/deploy/qwenfunc-logrotate.sh" /usr/local/sbin/qwenfunc-logrotate.sh

# ─── 4. Configuration ────────────────────────────────────────────────────────
log "Installing configuration…"
sudo install -m 0644 -o root -g qwenfunc "$REPO_ROOT/specs/04-tool-schema.json" /etc/qwenfunc/tool-schema.json
sudo install -m 0640 -o root -g qwenfunc "$REPO_ROOT/specs/05-rbac-policy.yaml" /etc/qwenfunc/policy.yaml

if [[ ! -f /etc/qwenfunc/config.toml ]]; then
    sudo tee /etc/qwenfunc/config.toml >/dev/null <<'EOF'
# QwenFunc runtime configuration. Edit and restart any running CLI sessions.
model_endpoint = "http://127.0.0.1:11434"
model_name = "qwen2.5:0.5b"
model_timeout_s = 30.0
operator_timeout_s = 5.0
total_deadline_s = 90.0
iteration_cap = 3
schema_path = "/etc/qwenfunc/tool-schema.json"
policy_path = "/etc/qwenfunc/policy.yaml"
log_path = "/var/log/qwenfunc/decisions.jsonl"
EOF
    sudo chown root:qwenfunc /etc/qwenfunc/config.toml
    sudo chmod 0640 /etc/qwenfunc/config.toml
fi

# ─── 5. Lint policy (deploy gate) ────────────────────────────────────────────
log "Linting policy…"
python3 "$REPO_ROOT/src/qwenfunc/lint_policy.py" \
    /etc/qwenfunc/policy.yaml \
    /etc/qwenfunc/tool-schema.json \
    --behavior-spec "$REPO_ROOT/specs/01-behavior.md" \
    --strict \
    || fail "policy lint failed — fix policy before continuing"

# ─── 6. AppArmor profiles ────────────────────────────────────────────────────
log "Installing AppArmor profiles…"
sudo tee /etc/apparmor.d/usr.local.bin.qwenfunc-cli >/dev/null <<'EOF'
#include <tunables/global>

profile qwenfunc-cli /usr/local/bin/qwenfunc-cli {
  #include <abstractions/base>
  #include <abstractions/python>

  /usr/bin/python3* ix,
  /usr/local/bin/qwenfunc-cli r,
  /usr/local/lib/qwenfunc/** r,

  # Config (read-only)
  /etc/qwenfunc/** r,

  # State + logs (rw)
  /var/lib/qwenfunc/ rw,
  /var/lib/qwenfunc/** rw,
  /var/log/qwenfunc/ rw,
  /var/log/qwenfunc/** rw,
  /run/qwenfunc/ rw,
  /run/qwenfunc/** rw,

  # Network: loopback only.
  network inet stream,
  network inet6 stream,
  deny network inet dgram,
  deny network inet6 dgram,

  # Allowed children: sudo (to invoke operator) and that's it.
  /usr/bin/sudo Px -> sudo_for_qwenfunc,

  # Deny capabilities.
  deny capability sys_admin,
  deny capability dac_override,
  deny capability dac_read_search,
}

profile sudo_for_qwenfunc /usr/bin/sudo {
  #include <abstractions/base>
  #include <abstractions/authentication>
  /usr/bin/sudo r,
  /etc/sudoers r,
  /etc/sudoers.d/ r,
  /etc/sudoers.d/** r,
  /usr/local/libexec/op-reader Px -> op-reader,
  capability setuid,
  capability setgid,
  capability audit_write,
}
EOF

sudo tee /etc/apparmor.d/usr.local.libexec.op-reader >/dev/null <<'EOF'
#include <tunables/global>

profile op-reader /usr/local/libexec/op-reader {
  #include <abstractions/base>
  #include <abstractions/python>

  /usr/bin/python3* ix,
  /usr/local/libexec/op-reader r,

  # Read-only filesystem access EXCEPT the OOS-5 corpus.
  / r,
  /** r,

  # OOS-5: explicit denies. Kept in sync with specs/01-behavior.md §6.
  deny /etc/shadow rwklx,
  deny /etc/gshadow rwklx,
  deny /etc/sudoers rwklx,
  deny /etc/sudoers.d/** rwklx,
  deny /root/** rwklx,
  deny /home/*/.ssh/** rwklx,
  deny /var/log/** rwklx,
  deny /proc/*/mem rwklx,
  deny /proc/kcore rwklx,
  deny /sys/kernel/** rwklx,
  deny /dev/mem rwklx,
  deny /dev/kmem rwklx,

  # No writes anywhere. No network. No exec. No mounts.
  deny /** w,
  deny network,
  deny capability,
  deny mount,
  deny pivot_root,
}
EOF

sudo apparmor_parser -r /etc/apparmor.d/usr.local.bin.qwenfunc-cli || fail "AppArmor parse failed (wrapper)"
sudo apparmor_parser -r /etc/apparmor.d/usr.local.libexec.op-reader || fail "AppArmor parse failed (operator)"
sudo aa-status | grep -q qwenfunc-cli || fail "wrapper profile not loaded"
sudo aa-status | grep -q op-reader   || fail "operator profile not loaded"

# ─── 7. sudoers ──────────────────────────────────────────────────────────────
log "Installing sudoers entry…"
sudo tee /etc/sudoers.d/qwenfunc >/dev/null <<'EOF'
# QwenFunc sudoers entry. See specs/03-architecture.md §6 + §7.
# Two entries:
#   1. Members of qwenfunc-users may invoke the wrapper as uid=qwenfunc.
#   2. The wrapper (running as qwenfunc) may invoke the operator as op-reader.

%qwenfunc-users ALL=(qwenfunc) NOPASSWD: /usr/local/bin/qwenfunc-cli
qwenfunc        ALL=(op-reader) NOPASSWD: /usr/local/libexec/op-reader

Defaults!/usr/local/libexec/op-reader !requiretty, env_reset
EOF
sudo chmod 0440 /etc/sudoers.d/qwenfunc
sudo visudo -c -f /etc/sudoers.d/qwenfunc >/dev/null || fail "sudoers syntax invalid"

# ─── 8. Audit rules ──────────────────────────────────────────────────────────
log "Installing audit rules…"
sudo tee /etc/audit/rules.d/qwenfunc.rules >/dev/null <<'EOF'
# QwenFunc audit watches. Tampering with policy/schema/operator/sudoers
# triggers an event in /var/log/audit/audit.log.
-w /etc/qwenfunc/policy.yaml -p wa -k qwenfunc_policy
-w /etc/qwenfunc/tool-schema.json -p wa -k qwenfunc_policy
-w /etc/qwenfunc/canary-corpus.yaml -p wa -k qwenfunc_policy
-w /usr/local/libexec/op-reader -p wa -k qwenfunc_binary
-w /etc/sudoers.d/qwenfunc -p wa -k qwenfunc_sudoers
EOF
sudo augenrules --load
sudo auditctl -l | grep -q qwenfunc_policy || fail "audit rules not loaded"

# ─── 9. Append-only log file ─────────────────────────────────────────────────
log "Setting up append-only log…"
sudo touch /var/log/qwenfunc/decisions.jsonl
sudo chown qwenfunc:adm /var/log/qwenfunc/decisions.jsonl
sudo chmod 0640 /var/log/qwenfunc/decisions.jsonl
sudo chattr +a /var/log/qwenfunc/decisions.jsonl

# ─── 10. Logrotate timer ─────────────────────────────────────────────────────
log "Installing logrotate units…"
sudo install -m 0644 "$REPO_ROOT/deploy/qwenfunc-logrotate.service" /etc/systemd/system/
sudo install -m 0644 "$REPO_ROOT/deploy/qwenfunc-logrotate.timer" /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now qwenfunc-logrotate.timer

# ─── 11. Smoke test ──────────────────────────────────────────────────────────
log "Running smoke test (denylist deny on /etc/shadow)…"
# This requires fresh shell membership in qwenfunc-users; if not, sudo with -E
SMOKE_OUT=$(sudo -u qwenfunc /usr/local/bin/qwenfunc-cli --no-identity-check --prompt "DENIED_SMOKE_TEST" 2>&1 || true)
if [[ "$SMOKE_OUT" == *"no permitted action"* ]]; then
    echo "  ✓ smoke test: wrapper rejects unmatched prompt"
else
    echo "  WARN: smoke test output unexpected: $SMOKE_OUT"
fi

# ─── Done ────────────────────────────────────────────────────────────────────
log "Install complete."
echo ""
echo "Try: qwenfunc"
echo "Logs: tail -f /var/log/qwenfunc/decisions.jsonl"
echo "Audit: ausearch -k qwenfunc_policy"
echo ""
echo "If 'qwenfunc-users' is a new group for you, log out and back in."
