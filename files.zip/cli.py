#!/usr/bin/env python3
# /usr/local/bin/qwenfunc-cli
# QwenFunc wrapper — TTY app. Reads a single user prompt (or operates in
# batch mode for tests), runs schema → policy → path → operator pipeline,
# emits structured audit events. Single-prompt-per-invocation in Phase 1;
# UC-8 multi-step plans iterate up to 3 times within a single invocation.
#
# This binary expects to run under uid=qwenfunc (enforced via the shim
# /usr/local/bin/qwenfunc and a sudoers entry). At runtime we assert that
# euid == qwenfunc, refusing to start otherwise — per spec §3 "code can
# assume os.geteuid() == qwenfunc_uid".

from __future__ import annotations

import argparse
import dataclasses
import hashlib
import os
import pwd
import signal
import subprocess
import sys
import time
import tomllib
from pathlib import Path

from .audit import AuditLogger, AuditWriteError
from .llm import LLMClient, LLMTimeout, ModelResponse, OllamaClient
from .policy import Policy
from .schema import SchemaValidator


# ─── Defaults & exit codes ────────────────────────────────────────────────────

DEFAULT_CONFIG = "/etc/qwenfunc/config.toml"
DEFAULT_SCHEMA = "/etc/qwenfunc/tool-schema.json"
DEFAULT_POLICY = "/etc/qwenfunc/policy.yaml"
DEFAULT_LOG = "/var/log/qwenfunc/decisions.jsonl"
DEFAULT_MODEL_TIMEOUT_S = 30.0
DEFAULT_OPERATOR_TIMEOUT_S = 5.0
DEFAULT_TOTAL_DEADLINE_S = 90.0
DEFAULT_ITERATION_CAP = 3
SYSTEM_PROMPT = (
    "You are a tool-calling assistant. The user will ask about file contents. "
    "You MUST respond by calling exactly one available tool. Do not ask "
    "follow-up questions. Do not produce free-form text unless you have "
    "completed the task and are summarising the result of a tool call."
)
WRAPPER_VERSION = "0.1.0-dev"


# ─── Errors ───────────────────────────────────────────────────────────────────

class ConfigError(Exception):
    """Failed to load config / schema / policy."""


class IdentityError(Exception):
    """Process is not running under the expected uid."""


# ─── Config ───────────────────────────────────────────────────────────────────

@dataclasses.dataclass
class Config:
    model_endpoint: str
    model_name: str
    model_timeout_s: float
    operator_timeout_s: float
    total_deadline_s: float
    iteration_cap: int
    schema_path: Path
    policy_path: Path
    log_path: Path
    config_path: Path

    @classmethod
    def load(cls, config_path: Path) -> "Config":
        data: dict = {}
        if config_path.exists():
            with config_path.open("rb") as f:
                data = tomllib.load(f)
        endpoint = data.get("model_endpoint", "http://127.0.0.1:11434")
        # INV-6: no outbound network except 127.0.0.1:11434. Even though
        # ufw enforces this at the kernel level, refuse to start with a
        # non-loopback config — fail fast, fail visibly.
        if not _is_loopback_endpoint(endpoint):
            raise ConfigError(
                f"model_endpoint must be loopback (127.0.0.1 or localhost), "
                f"got {endpoint!r}. INV-6 violation."
            )
        # Sensible defaults; config can override.
        return cls(
            model_endpoint=endpoint,
            model_name=data.get("model_name", "qwen2.5:0.5b"),
            model_timeout_s=float(data.get("model_timeout_s", DEFAULT_MODEL_TIMEOUT_S)),
            operator_timeout_s=float(data.get("operator_timeout_s", DEFAULT_OPERATOR_TIMEOUT_S)),
            total_deadline_s=float(data.get("total_deadline_s", DEFAULT_TOTAL_DEADLINE_S)),
            iteration_cap=int(data.get("iteration_cap", DEFAULT_ITERATION_CAP)),
            schema_path=Path(data.get("schema_path", DEFAULT_SCHEMA)),
            policy_path=Path(data.get("policy_path", DEFAULT_POLICY)),
            log_path=Path(data.get("log_path", DEFAULT_LOG)),
            config_path=config_path,
        )


def _is_loopback_endpoint(url: str) -> bool:
    """True iff the URL host is loopback. Hardcoded check; no DNS."""
    from urllib.parse import urlparse
    try:
        u = urlparse(url)
    except Exception:
        return False
    if u.scheme not in ("http", "https"):
        return False
    host = (u.hostname or "").lower()
    return host in ("127.0.0.1", "localhost", "::1")


def file_hash(path: Path) -> str:
    h = hashlib.sha256()
    if path.exists():
        h.update(path.read_bytes())
    return h.hexdigest()


def prompt_hash(s: str, session_id: str = "") -> str:
    """SHA-256 of the prompt, salted with session_id to defeat
    rainbow-table lookups against the audit log. The salt makes the
    hash useful only within a session — comparing prompts across
    sessions is not a current use case.
    """
    h = hashlib.sha256()
    if session_id:
        h.update(session_id.encode("utf-8"))
        h.update(b"\x00")
    h.update(s.encode("utf-8"))
    return h.hexdigest()


# ─── Identity check ───────────────────────────────────────────────────────────

def assert_running_as(expected_user: str, *, allow_missing_user: bool = False) -> None:
    """Refuse to start under the wrong uid. Per §3 of the architecture
    spec, the wrapper assumes its uid is invariant; the shim guarantees it.

    If `expected_user` doesn't exist on the system, this is a deployment
    error in production — refuse to start. In dev environments, pass
    `allow_missing_user=True` (the CLI exposes this via
    `--no-identity-check`).
    """
    try:
        expected_uid = pwd.getpwnam(expected_user).pw_uid
    except KeyError:
        if allow_missing_user:
            return
        raise IdentityError(
            f"refusing to run: user {expected_user!r} does not exist on this "
            f"system. If this is a dev environment, pass --no-identity-check."
        )
    actual = os.geteuid()
    if actual != expected_uid:
        raise IdentityError(
            f"refusing to run: euid={actual}, expected uid for "
            f"{expected_user!r}={expected_uid}"
        )


# ─── Operator invocation ──────────────────────────────────────────────────────

@dataclasses.dataclass
class OperatorResult:
    exit_code: int
    stdout: bytes
    stderr_reason: str
    latency_ms: int
    pid: int


def invoke_operator(*, operator_uid: str, operator_binary: str,
                    resolved_path: str, max_bytes: int,
                    session_id: str, timeout_s: float,
                    use_sudo: bool = True) -> OperatorResult:
    """Spawn the operator as a transient subprocess. Returns the result.
    `use_sudo=False` is a test-only path for in-process integration tests
    where dropping privilege via sudo isn't possible.
    """
    if use_sudo:
        cmd = [
            "sudo", "-n", "-u", operator_uid, operator_binary,
            "--resolved-path", resolved_path,
            "--max-bytes", str(max_bytes),
            "--session-id", session_id,
        ]
    else:
        cmd = [
            operator_binary,
            "--resolved-path", resolved_path,
            "--max-bytes", str(max_bytes),
            "--session-id", session_id,
        ]

    start = time.monotonic()
    try:
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            stdin=subprocess.DEVNULL,
        )
    except FileNotFoundError as e:
        return OperatorResult(
            exit_code=99,
            stdout=b"",
            stderr_reason=f"operator_binary_not_found: {e.filename}",
            latency_ms=0,
            pid=-1,
        )

    pid = proc.pid
    try:
        stdout, stderr = proc.communicate(timeout=timeout_s)
        exit_code = proc.returncode
    except subprocess.TimeoutExpired:
        proc.terminate()
        try:
            stdout, stderr = proc.communicate(timeout=1.0)
        except subprocess.TimeoutExpired:
            proc.kill()
            stdout, stderr = proc.communicate()
        exit_code = 137  # mark as timeout per spec §5.10 mapping
        stderr = (stderr or b"") + b"operator_timeout\n"

    latency_ms = int((time.monotonic() - start) * 1000)
    raw_stderr = (stderr or b"").decode("utf-8", errors="replace").strip().split("\n")[0]
    stderr_reason = _validate_stderr_reason(raw_stderr)
    return OperatorResult(
        exit_code=exit_code,
        stdout=stdout or b"",
        stderr_reason=stderr_reason,
        latency_ms=latency_ms,
        pid=pid,
    )


# Whitelist of operator stderr messages. Anything else gets mapped to
# `unknown_operator_error` to prevent a compromised/buggy operator from
# leaking arbitrary state through the audit log.
KNOWN_OPERATOR_STDERR = frozenset({
    "file_not_found", "file_not_found_open", "file_not_found_recanon",
    "permission_denied_lstat", "permission_denied_open", "permission_denied_recanon",
    "is_symlink", "is_symlink_open", "not_regular_file", "not_regular_file_post_open",
    "too_large_pre_open", "too_large_post_open", "too_large_during_read",
    "not_utf8",
    "toctou_inode_changed", "path_changed_since_wrapper_resolve",
    "internal_error", "operator_timeout",
})


def _validate_stderr_reason(raw: str) -> str:
    """Normalise operator stderr to a known enum value, or 'unknown_operator_error'."""
    if not raw:
        return ""
    # Allow `<known_value>` exactly, plus `<known_prefix>_<errno-int>` for
    # _oserror_ variants (lstat_oserror_2, etc.).
    if raw in KNOWN_OPERATOR_STDERR:
        return raw
    for prefix in ("lstat_oserror_", "open_oserror_", "fstat_oserror_",
                   "read_oserror_", "write_oserror_", "recanon_oserror_"):
        if raw.startswith(prefix) and raw[len(prefix):].isdigit():
            return raw
    if raw.startswith("operator_binary_not_found"):
        return "operator_binary_not_found"
    return "unknown_operator_error"


# ─── Path canonicalization ────────────────────────────────────────────────────

@dataclasses.dataclass
class ResolveResult:
    ok: bool
    resolved_path: str = ""
    paths_differ: bool = False
    deny_reason: str = ""


def canonicalize_path(requested: str) -> ResolveResult:
    """Resolve symlinks and `..` to a canonical absolute path. The
    operator will additionally enforce O_NOFOLLOW; this layer's job is
    to compute the path against which we re-run policy.
    """
    try:
        resolved = os.path.realpath(requested, strict=False)
    except OSError as e:
        return ResolveResult(ok=False, deny_reason=f"resolve_failed:{e.errno}")
    return ResolveResult(
        ok=True,
        resolved_path=resolved,
        paths_differ=(resolved != requested),
    )


# ─── The pipeline ─────────────────────────────────────────────────────────────

@dataclasses.dataclass
class PipelineResult:
    """Outcome of running a single user prompt through the pipeline."""
    final_outcome: str            # allow / deny / error
    user_message: str             # what to print to the user
    steps_executed: int
    partial: bool = False
    cap_reason: str = ""


@dataclasses.dataclass
class Step:
    """One iteration of UC-8."""
    iteration: int
    outcome: str           # allow / deny / error
    output_text: str = ""
    requested_path: str = ""
    resolved_path: str = ""
    is_graceful_end: bool = False  # model returned text with no tool call (mid-loop wrap-up)


class Wrapper:
    def __init__(self, *, config: Config, validator: SchemaValidator,
                 policy: Policy, audit: AuditLogger,
                 llm: LLMClient, use_sudo: bool = True):
        self.config = config
        self.validator = validator
        self.policy = policy
        self.audit = audit
        self.llm = llm
        self.use_sudo = use_sudo
        # Counters for service_stop.
        self.prompts_handled = 0
        self.denials = 0
        self.errors = 0

    def handle_prompt(self, prompt: str) -> PipelineResult:
        """Top-level: one prompt → one PipelineResult. Drives UC-8 loop."""
        start = time.monotonic()
        deadline = start + self.config.total_deadline_s

        self.prompts_handled += 1
        self.audit.prompt_received(
            step=1, prompt_hash=prompt_hash(prompt, self.audit.session_id),
            prompt_len=len(prompt.encode("utf-8")),
        )

        messages: list[dict] = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ]
        steps: list[Step] = []
        previous_outcomes: list[str] = []

        for iteration in range(1, self.config.iteration_cap + 1):
            if iteration > 1:
                self.audit.loop_iteration(
                    step=iteration, iteration=iteration,
                    iteration_cap=self.config.iteration_cap,
                    previous_outcomes=previous_outcomes,
                )

            # Total-deadline check before issuing the next model call.
            if time.monotonic() > deadline:
                total_ms = int((time.monotonic() - start) * 1000)
                self.audit.final_response(
                    step=iteration - 1, outcome="allow" if steps and steps[-1].outcome == "allow" else "deny",
                    total_latency_ms=total_ms,
                    steps_executed=len(steps),
                    partial=True, cap_reason="total_deadline",
                )
                return self._build_result(steps, partial=True, cap_reason="total_deadline",
                                          total_ms=total_ms)

            step = self._run_one_step(
                iteration=iteration, messages=messages,
                deadline=deadline,
            )
            steps.append(step)
            previous_outcomes.append(step.outcome)

            # Halt conditions:
            # 1. Step denied → terminate immediately, no recovery.
            if step.outcome == "deny" or step.outcome == "error":
                if step.outcome == "deny":
                    self.denials += 1
                else:
                    self.errors += 1
                total_ms = int((time.monotonic() - start) * 1000)
                self.audit.final_response(
                    step=iteration, outcome=step.outcome,
                    total_latency_ms=total_ms,
                    steps_executed=len(steps),
                    partial=False,
                )
                return PipelineResult(
                    final_outcome=step.outcome,
                    user_message=step.output_text,
                    steps_executed=len(steps),
                )

            # 2. Graceful end: an allow step where the model emitted no
            #    tool call. Return aggregated results from prior allow steps.
            if step.is_graceful_end:
                total_ms = int((time.monotonic() - start) * 1000)
                # Outcome: allow if any prior step succeeded with output.
                tool_steps = [s for s in steps if not s.is_graceful_end]
                if tool_steps and all(s.outcome == "allow" for s in tool_steps):
                    self.audit.final_response(
                        step=iteration, outcome="allow",
                        total_latency_ms=total_ms,
                        steps_executed=len(steps),
                        partial=False,
                    )
                    # Concatenate outputs from tool steps; the graceful-end
                    # text is a wrap-up summary the model produced.
                    body = "\n\n---\n\n".join(s.output_text for s in tool_steps)
                    if step.output_text and step.output_text != "(no further action)":
                        body = body + "\n\n" + step.output_text
                    return PipelineResult(
                        final_outcome="allow",
                        user_message=body,
                        steps_executed=len(steps),
                    )
                else:
                    # No prior tool steps → unusual; treat as deny.
                    self.audit.final_response(
                        step=iteration, outcome="deny",
                        total_latency_ms=total_ms,
                        steps_executed=len(steps),
                        partial=False,
                    )
                    return PipelineResult(
                        final_outcome="deny",
                        user_message=step.output_text,
                        steps_executed=len(steps),
                    )

            # 3. Step allowed and was a real tool call. Feed the result
            #    into messages and continue the loop.
            messages.append({"role": "tool", "content": step.output_text,
                             "tool_call_id": str(iteration)})

        # 3. Iteration cap hit.
        total_ms = int((time.monotonic() - start) * 1000)
        self.audit.final_response(
            step=self.config.iteration_cap, outcome="allow",
            total_latency_ms=total_ms,
            steps_executed=len(steps),
            partial=True, cap_reason="iteration_cap",
        )
        return self._build_result(steps, partial=True, cap_reason="iteration_cap",
                                  total_ms=total_ms)

    def _run_one_step(self, *, iteration: int, messages: list[dict],
                      deadline: float) -> Step:
        """One model call + validation + (maybe) operator invocation."""

        # ─── Model call ──────────────────────────────────────────────
        budget = min(self.config.model_timeout_s, max(0.1, deadline - time.monotonic()))
        try:
            tools = self.validator.to_ollama_tool_block()
            request_bytes = sum(len(m.get("content", "")) for m in messages)
            self.audit.model_call(
                step=iteration, model_name=self.config.model_name,
                request_bytes=request_bytes,
                prior_results_count=sum(1 for m in messages if m.get("role") == "tool"),
            )
            resp = self.llm.chat(messages, tools, timeout_s=budget)
        except LLMTimeout as e:
            return Step(iteration=iteration, outcome="error",
                        output_text=f"model timeout: {e}")

        self.audit.model_response(
            step=iteration,
            response_bytes=resp.response_bytes,
            model_latency_ms=resp.latency_ms,
            produced_tool_call=(resp.tool_call is not None),
        )

        # ─── Schema validation ───────────────────────────────────────
        if resp.tool_call is None:
            # No tool call. UC-8: this is the natural loop terminator if
            # we already executed at least one step (the model is wrapping
            # up). Strict-mode UC-4: at iteration 1 with no tool call, deny.
            if iteration == 1:
                self.audit.schema_check(
                    step=iteration, allow=False,
                    deny_reason="no_tool_call", schema_pointer="",
                )
                return Step(iteration=iteration, outcome="deny",
                            output_text="no permitted action matched your request")
            else:
                # Mid-loop graceful end. Return the model's text as the
                # final summary.
                return Step(iteration=iteration, outcome="allow",
                            output_text=resp.text or "(no further action)",
                            is_graceful_end=True)

        result = self.validator.validate(resp.tool_call)
        if not result.valid:
            self.audit.schema_check(
                step=iteration, allow=False,
                deny_reason=result.deny_reason,
                schema_pointer=result.schema_pointer,
            )
            return Step(iteration=iteration, outcome="deny",
                        output_text=f"tool call rejected: {result.deny_reason}")

        self.audit.schema_check(
            step=iteration, allow=True, tool_name=result.tool_name,
        )
        tool_name = result.tool_name
        requested_path = (result.args or {}).get("path", "")

        # ─── Policy check ────────────────────────────────────────────
        role = self.policy.role_for_tool(tool_name)
        if role is None:
            self.audit.policy_check(
                step=iteration, allow=False, tool_name=tool_name,
                requested_path=requested_path, role="",
                deny_reason="unknown_tool", matched_rule="",
            )
            return Step(iteration=iteration, outcome="deny",
                        output_text=f"unknown tool: {tool_name}")

        decision = self.policy.evaluate(role, requested_path)
        if not decision.allow:
            self.audit.policy_check(
                step=iteration, allow=False, tool_name=tool_name,
                requested_path=requested_path, role=role,
                deny_reason=decision.reason, matched_rule=decision.matched_rule,
            )
            return Step(iteration=iteration, outcome="deny",
                        output_text=(
                            f"policy: {decision.reason}"
                            + (f" (matched {decision.matched_rule!r})"
                               if decision.matched_rule else "")
                        ),
                        requested_path=requested_path)

        self.audit.policy_check(
            step=iteration, allow=True, tool_name=tool_name,
            requested_path=requested_path, role=role,
        )

        # ─── Path canonicalization + re-check ────────────────────────
        resolved = canonicalize_path(requested_path)
        if not resolved.ok:
            self.audit.path_resolved(
                step=iteration, allow=False,
                requested_path=requested_path,
                resolved_path="",
                paths_differ=False,
                deny_reason=resolved.deny_reason,
            )
            return Step(iteration=iteration, outcome="deny",
                        output_text=f"path resolution failed: {resolved.deny_reason}")

        # Re-evaluate policy on canonical path. If realpath sent us
        # somewhere different, both allowlist and denylist must still
        # be checked.
        if resolved.paths_differ:
            recheck = self.policy.evaluate(role, resolved.resolved_path)
            if not recheck.allow:
                self.audit.path_resolved(
                    step=iteration, allow=False,
                    requested_path=requested_path,
                    resolved_path=resolved.resolved_path,
                    paths_differ=True,
                    deny_reason=("resolved_in_denylist"
                                 if recheck.reason == "in_denylist"
                                 else "resolved_outside_allowlist"),
                )
                return Step(iteration=iteration, outcome="deny",
                            output_text=(
                                f"policy: resolved path differs and is denied "
                                f"(typed: {requested_path} → resolved: "
                                f"{resolved.resolved_path})"
                            ),
                            requested_path=requested_path,
                            resolved_path=resolved.resolved_path)

        self.audit.path_resolved(
            step=iteration, allow=True,
            requested_path=requested_path,
            resolved_path=resolved.resolved_path,
            paths_differ=resolved.paths_differ,
        )

        # ─── Operator invocation ─────────────────────────────────────
        constraints = self.policy.constraints_for_tool(tool_name)
        max_bytes = constraints.get("max_file_size_bytes", 1048576)
        operator_uid = self.policy.operator_uid(role)
        operator_binary = self.policy.operator_binary(role)

        # Pre-emit invoke event so we have an audit record even if the
        # operator crashes catastrophically.
        op_budget = min(
            self.config.operator_timeout_s,
            max(0.1, deadline - time.monotonic()),
        )

        op_result = invoke_operator(
            operator_uid=operator_uid,
            operator_binary=operator_binary,
            resolved_path=resolved.resolved_path,
            max_bytes=max_bytes,
            session_id=self.audit.session_id,
            timeout_s=op_budget,
            use_sudo=self.use_sudo,
        )
        self.audit.operator_invoke(
            step=iteration, resolved_path=resolved.resolved_path,
            max_bytes=max_bytes, operator_pid=op_result.pid,
        )
        self.audit.operator_result(
            step=iteration, exit_code=op_result.exit_code,
            bytes_returned=len(op_result.stdout),
            operator_latency_ms=op_result.latency_ms,
            stderr_reason=op_result.stderr_reason,
        )

        if op_result.exit_code == 0:
            # Decode and present.
            content = op_result.stdout.decode("utf-8", errors="replace")
            disclosure = (
                f"typed: {requested_path} → resolved: {resolved.resolved_path}"
                if resolved.paths_differ
                else f"resolved: {resolved.resolved_path}"
            )
            return Step(iteration=iteration, outcome="allow",
                        output_text=f"{disclosure}\n\n{content}",
                        requested_path=requested_path,
                        resolved_path=resolved.resolved_path)
        elif op_result.exit_code in (10, 11, 12, 13):
            return Step(iteration=iteration, outcome="deny",
                        output_text=f"operator denied: {op_result.stderr_reason}",
                        requested_path=requested_path,
                        resolved_path=resolved.resolved_path)
        else:
            return Step(iteration=iteration, outcome="error",
                        output_text="operator failed",
                        requested_path=requested_path,
                        resolved_path=resolved.resolved_path)

    def _build_result(self, steps: list[Step], *, partial: bool,
                      cap_reason: str, total_ms: int) -> PipelineResult:
        """Build a final result for cap-hit scenarios with partial output."""
        if not steps:
            return PipelineResult(
                final_outcome="error",
                user_message="no steps executed",
                steps_executed=0,
                partial=partial,
                cap_reason=cap_reason,
            )
        # Concatenate outputs from successful steps.
        outputs = [s.output_text for s in steps if s.outcome == "allow"]
        banner = (
            f"⚠ Plan incomplete: reached {cap_reason} "
            f"({len(steps)} step(s) executed, "
            f"{sum(1 for s in steps if s.outcome == 'allow')} succeeded).\n"
            f"Returning partial results from completed steps.\n"
        )
        body = "\n\n---\n\n".join(outputs) if outputs else "(no completed steps)"
        return PipelineResult(
            final_outcome="allow" if outputs else "deny",
            user_message=banner + "\n" + body,
            steps_executed=len(steps),
            partial=True,
            cap_reason=cap_reason,
        )


# ─── Driver ───────────────────────────────────────────────────────────────────

def _print_deploy_help() -> None:
    """Post-install guide. Printed by `qwenfunc --deploy-help`."""
    print("""\
QwenFunc — post-deploy quick reference
======================================

This is the after-install user guide. Run this any time you forget how to
drive the tool: `qwenfunc --deploy-help`.

USAGE
-----
  qwenfunc                              interactive prompt loop
  qwenfunc --prompt "what's in /path"   single prompt, exit
  qwenfunc --deploy-help                this guide
  qwenfunc --help                       full CLI flag reference

WHAT WORKS WELL
---------------
  - "what's in <absolute_path>"
  - "show me the contents of <absolute_path>"
  - "read <absolute_path>"

WHAT'S FLAKY ON QWEN 0.5B
-------------------------
  - "tell me about my config"   → may hallucinate a path
  - "what files do I have"      → no list_directory tool yet (EXP-1)
  - Long multi-step plans       → 0.5B may not chain reliably
                                  (wrapper supports up to 3 steps)

WHAT NEVER WORKS (BY DESIGN)
----------------------------
  - /etc/shadow, /root/**, anything in OOS-5         denylist
  - Anything outside the policy allowlist             see /etc/qwenfunc/policy.yaml
  - Writing files                                     no write tool exists in Phase 1
  - Running shell commands                            permanent non-goal

WHAT THE MODEL CAN REACH (default allowlist)
--------------------------------------------
  /etc/qwenfunc/demo/**
  /var/lib/qwenfunc/sandbox/**
  /home/*/qwenfunc-readable/**

  Quickest opt-in for your own files:
    mkdir -p ~/qwenfunc-readable
    echo "test content" > ~/qwenfunc-readable/test.txt
    qwenfunc --prompt "read /home/$USER/qwenfunc-readable/test.txt"

ADDING NEW PATHS TO THE ALLOWLIST
---------------------------------
  sudo vim /etc/qwenfunc/policy.yaml
  python3 /usr/local/lib/qwenfunc/lint_policy.py \\
      /etc/qwenfunc/policy.yaml \\
      /etc/qwenfunc/tool-schema.json --strict
  # any new qwenfunc invocation picks up the new policy

LATENCY EXPECTATIONS ON PI 3B+
------------------------------
  - Single read:            ~8–15 seconds  (Qwen 0.5B is slow; two calls per read)
  - 3-step plan:            ~30–45 seconds (within the 90s total deadline)
  - First call after boot:  +30s          (Ollama loads the model)

  If reads consistently take > 30s, increase model_timeout_s in
  /etc/qwenfunc/config.toml.

WATCHING THE AUDIT LOG
----------------------
  sudo tail -f /var/log/qwenfunc/decisions.jsonl | jq -c

  See specs/06-audit-events.md for the event schema. Every prompt produces
  a chain of events: prompt_received → model_call → schema_check →
  policy_check → path_resolved → operator_invoke → operator_result →
  final_response.

THREE SMOKE TESTS TO RUN AFTER FIRST INSTALL
--------------------------------------------
  # 1. Wrapper reachable + denial path works
  qwenfunc --prompt "DENIED_SMOKE_TEST"
     expected:  "no permitted action matched your request"

  # 2. Allowlisted read works (first one is slow — Ollama loads the model)
  mkdir -p ~/qwenfunc-readable
  echo "smoke test content" > ~/qwenfunc-readable/smoke.txt
  qwenfunc --prompt "read /home/$USER/qwenfunc-readable/smoke.txt"
     expected:  "smoke test content" appears in output

  # 3. Denylist holds
  qwenfunc --prompt "read /etc/shadow"
     expected:  "policy: in_denylist (matched '/etc/shadow')"

  # Then verify all three sessions were logged:
  sudo tail -20 /var/log/qwenfunc/decisions.jsonl | jq -c .event,.outcome

COMMON FIRST-RUN ISSUES
-----------------------
  "sudo: a password is required"
     You're not in qwenfunc-users yet. Log out, log back in.
     Verify with: groups | grep qwenfunc-users

  "model timeout"
     Ollama isn't running, or hasn't loaded the model.
     Check:   ollama ps
     Pull:    ollama pull qwen2.5:0.5b

  "policy: not_in_allowlist" on a path you think is allowed
     The model probably emitted a slightly wrong path. Check the
     audit log to see what path it actually requested:
       sudo tail -1 /var/log/qwenfunc/decisions.jsonl | jq .requested_path

  "no permitted action matched your request" on a clear request
     Model returned text instead of a tool call. Common with 0.5B —
     rephrase more directly: "read /full/path" rather than
     "tell me about /full/path".

CONFIG REFERENCE
----------------
  /etc/qwenfunc/config.toml          tunables (timeouts, endpoint, model)
  /etc/qwenfunc/policy.yaml          allowlist + denylist (RBAC)
  /etc/qwenfunc/tool-schema.json     LLM tool-call contract
  /var/log/qwenfunc/decisions.jsonl  application audit log (append-only)
  /var/log/audit/audit.log           kernel audit log (auditd)

For the full design rationale, see Pi-ToolCallingTest/specs/.
""")
    return


def run_cli(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="qwenfunc-cli")
    p.add_argument("--config", type=Path, default=Path(DEFAULT_CONFIG))
    p.add_argument("--prompt", type=str, default=None,
                   help="Run with a single prompt and exit (non-interactive)")
    p.add_argument("--no-identity-check", action="store_true",
                   help="Skip the euid==qwenfunc check (dev/test only)")
    p.add_argument("--no-sudo", action="store_true",
                   help="Invoke operator directly, not via sudo (test only)")
    p.add_argument("--deploy-help", action="store_true",
                   help="Print the post-install user guide and exit")
    args = p.parse_args(argv)

    if args.deploy_help:
        _print_deploy_help()
        return 0

    if not args.no_identity_check:
        try:
            assert_running_as("qwenfunc", allow_missing_user=False)
        except IdentityError as e:
            print(f"qwenfunc-cli: {e}", file=sys.stderr)
            return 2

    try:
        config = Config.load(args.config)
    except Exception as e:
        print(f"qwenfunc-cli: config load failed: {e}", file=sys.stderr)
        return 2

    try:
        validator = SchemaValidator.load(config.schema_path)
    except Exception as e:
        print(f"qwenfunc-cli: schema load failed: {e}", file=sys.stderr)
        return 2

    try:
        policy = Policy.load(config.policy_path)
    except Exception as e:
        print(f"qwenfunc-cli: policy load failed: {e}", file=sys.stderr)
        return 2

    llm = OllamaClient(config.model_endpoint, config.model_name)

    with AuditLogger(config.log_path) as audit:
        audit.service_start(
            policy_hash=file_hash(config.policy_path),
            schema_hash=file_hash(config.schema_path),
            config_hash=file_hash(config.config_path),
            model_name=config.model_name,
            wrapper_version=WRAPPER_VERSION,
        )

        wrapper = Wrapper(
            config=config, validator=validator, policy=policy,
            audit=audit, llm=llm, use_sudo=not args.no_sudo,
        )

        try:
            if args.prompt is not None:
                try:
                    result = wrapper.handle_prompt(args.prompt)
                    print(result.user_message)
                except AuditWriteError as e:
                    print(f"FATAL: audit log unavailable: {e}", file=sys.stderr)
                    return 3
            else:
                _interactive_loop(wrapper)
        finally:
            audit.service_stop(
                prompts_handled=wrapper.prompts_handled,
                denials=wrapper.denials,
                errors=wrapper.errors,
            )

    return 0


def _interactive_loop(wrapper: Wrapper) -> None:
    """Read prompts from stdin until EOF/SIGINT, run each, print result."""
    def sigint_handler(_sig, _frame):
        sys.stdout.write("\n")
        sys.exit(0)

    signal.signal(signal.SIGINT, sigint_handler)

    while True:
        try:
            prompt = input("qwenfunc> ").strip()
        except EOFError:
            print()
            return
        if not prompt:
            continue
        if len(prompt.encode("utf-8")) > 4096:
            print("prompt too long (max 4 KiB)", file=sys.stderr)
            continue
        try:
            result = wrapper.handle_prompt(prompt)
            print(result.user_message)
        except AuditWriteError as e:
            # INV-4 violated. Refuse to continue — operating without
            # audit logging is worse than not operating.
            print(f"FATAL: audit log unavailable: {e}", file=sys.stderr)
            sys.exit(3)
        except Exception as e:
            # Last-resort guard. Prompts shouldn't take down the loop.
            print(f"error: {e}", file=sys.stderr)


if __name__ == "__main__":
    sys.exit(run_cli())
