# Pi-ToolCallingTest

Spec-driven implementation of **QwenFunc** — a local Python wrapper that lets a
locally-hosted LLM (Qwen 2.5 0.5B via Ollama) parse user intent and trigger
narrow, audited filesystem actions on a Raspberry Pi 3B+.

The model is treated as **untrusted output**. A wrapper running as `qwenfunc`
validates each tool call against a strict schema and an RBAC policy, then
delegates the actual file read to a separate operator (`op-reader`) running
under AppArmor confinement.

---

## Status

**Phase 1 — read-only with bounded agentic loop. Code complete, ready to deploy.**

| Layer | Status |
|---|---|
| Specs (6 docs) | Final |
| Policy linter + tests | 27/27 passing |
| Wrapper + operator + audit | 20/20 wrapper tests passing (incl. 7 security regressions) |
| Pi deploy script | Ready, layout-driven UIDs |
| AppArmor profiles | Embedded in deploy script |
| Pre-commit hook | Configured |
| Canary harness | TODO (after first Pi deploy) |
| Red-team prompt corpus | TODO (after first Pi deploy) |

---

## Repository layout

```
Pi-ToolCallingTest/
├── README.md                          this file
├── .pre-commit-config.yaml            CI / pre-commit linter & test gates
│
├── specs/                             contracts; reading order = file numbers
│   ├── 01-behavior.md                 use cases, OOS, expansion hooks
│   ├── 02-threat-model.md             STRIDE + OWASP LLM Top 10 + CIS
│   ├── 03-architecture.md             uid map, confinement layers, deploy
│   ├── 04-tool-schema.json            LLM tool-call contract (strict)
│   ├── 05-rbac-policy.yaml            allowlist + denylist + roles
│   └── 06-audit-events.md             JSON Lines log schema
│
├── src/
│   ├── qwenfunc/                      wrapper package
│   │   ├── cli.py                     entry point, prompt loop, UC-8 driver
│   │   ├── audit.py                   stdlib-syslog + append-only file logger
│   │   ├── policy.py                  policy loader + decision engine
│   │   ├── schema.py                  JSON Schema validator + classifier
│   │   ├── llm.py                     Ollama HTTP client (loopback only)
│   │   ├── globs.py                   ★ shared glob compiler (wrapper + linter)
│   │   ├── lint_policy.py             RBAC linter (CI gate, deploy gate)
│   │   └── bump_review_date.py        automated metadata.last_reviewed bump
│   └── op_reader/
│       └── op_reader.py               ★ privileged operator (separate uid)
│
├── tests/
│   ├── policy_lint/test_lint.py       27 tests (linter rules + cross-spec)
│   └── wrapper/test_wrapper.py        20 tests (UC-1..9 + 7 security regressions)
│
└── deploy/
    ├── install-on-pi.sh               idempotent installer + uninstaller
    ├── uid-layout.conf                ★ Pi 3B+ UID/GID assignments (default)
    ├── uid-layout.zero2w.conf         Pi Zero 2W layout (extension example)
    ├── qwenfunc                       /usr/local/bin shim (uid swap to qwenfunc)
    ├── qwenfunc-logrotate.sh          chattr +a-aware log rotator
    ├── qwenfunc-logrotate.service     systemd unit
    └── qwenfunc-logrotate.timer       monthly rotation
```

★ = security-critical / single-source-of-truth files.

---

## Quick start (Raspberry Pi 3B+)

**Preconditions:**
- Debian Trixie installed
- `harden-pi.sh` (parent `test-stage/` repo) has been run
- Ollama installed and `qwen2.5:0.5b` pulled
- This repo cloned

**Install:**
```bash
cd Pi-ToolCallingTest
./deploy/install-on-pi.sh
# log out + back in for qwenfunc-users group membership
```

**Run:**
```bash
qwenfunc --deploy-help          # post-install user guide
qwenfunc --prompt "DENIED_SMOKE_TEST"
mkdir -p ~/qwenfunc-readable
echo "hello world" > ~/qwenfunc-readable/test.txt
qwenfunc --prompt "read /home/$USER/qwenfunc-readable/test.txt"
```

**Watch the audit log:**
```bash
sudo tail -f /var/log/qwenfunc/decisions.jsonl | jq -c
```

**Uninstall:**
```bash
./deploy/install-on-pi.sh --uninstall
```

---

## Deploying to a different Pi

UIDs/GIDs are externalized to `deploy/uid-layout.conf`. To deploy to another
platform (Pi Zero 2W, Pi 5, future hardware):

1. Copy `deploy/uid-layout.conf` to `deploy/uid-layout.<platform>.conf`
2. Edit UIDs/GIDs if you need to avoid collisions on that platform
3. Pass the layout file to the installer:
   ```bash
   ./deploy/install-on-pi.sh --uid-layout deploy/uid-layout.zero2w.conf
   ```

The installer detects UID drift — if a user already exists at a different UID
than the layout requires, it refuses to silently rebuild. This protects backup
restores and SD card migrations from breaking file ownership.

---

## Security model (one paragraph)

The model is untrusted; the wrapper is the security boundary. Six confinement
layers stack: kernel DAC (separate uids), sudoers (one entry pinning the
operator binary, env_reset), systemd unit hardening, AppArmor (per-binary
profile, `deny` rules for OOS-5 sensitive paths), application RBAC (allowlist
+ denylist + size + UTF-8 + symlink check), and a daily canary suite that
exercises the entire stack via the real privilege boundary. The OOS-5 list is
triple-encoded (Python policy, AppArmor profile, canary corpus) — drift
between the three is itself a test failure. See `specs/02-threat-model.md` for
the full STRIDE / OWASP LLM Top 10 / CIS mapping.

---

## Testing

```bash
# Linter tests (no network, no Pi-specific anything):
python3 tests/policy_lint/test_lint.py

# Wrapper tests (uses fake LLM, runs operator without sudo):
python3 tests/wrapper/test_wrapper.py
```

Both run on macOS for development; CI gate is the same two commands plus the
linter against the actual policy + schema files.

After Pi deploy, additional tests requiring real Ollama:

| # | Test | Why it can only run on Pi |
|---|---|---|
| 1 | Real allowlisted read | Needs Qwen to actually emit a tool call |
| 2 | Red-team prompt corpus (10 categories) | Threat model §11.1 R1 measurement |
| 3 | Multi-step UC-8 with real model | Whether 0.5B chains tool calls |
| 4 | Latency p50/p95/p99 profiling | Real hardware needed |
| 5 | Canary as `qwenfunc` | Real sudo + AppArmor stack |
| 6 | Canary as `canary-tester` | Verifies privilege boundary |
| 7 | AppArmor enforcement | Kernel-level policy active |
| 8 | `chattr +a` enforcement | Real auditd rules loaded |

---

## Conventions referenced across the repo

- **UC-N** — in-scope use cases (`01-behavior.md` §4)
- **OOS-N** — out-of-scope, deny-listed at runtime (`01-behavior.md` §6)
- **EXP-N** — anticipated future scope (`01-behavior.md` §7)
- **INV-N** — security invariants (`02-threat-model.md` §6)
- **T*N.M*** — STRIDE threats per boundary (`02-threat-model.md` §5)
- **R*N*** — residual risks accepted (`02-threat-model.md` §11)
- **L*NN*** — OWASP LLM Top 10 2025 categories

---

## License & ownership

Personal project, single-user Pi. Canonical repo is `Jaggu-GT/test-stage`.
macOS is the dev machine; Pi 3B+ is the runtime. No telemetry, no cloud,
no remote access (Phase 1).
